"""Reads a video file, a network stream (rtsp/http) or a camera, and yields sampled frames."""
from __future__ import annotations

import time
from dataclasses import dataclass

import cv2


@dataclass
class Frame:
    index: int          # frame number in the source
    time_s: float       # seconds from the start
    image: "object"     # BGR numpy array


class VideoSource:
    def __init__(self, source: str, sample_every_seconds: float = 1.0, every_n_frames: int | None = None,
                 max_seconds: float | None = None):
        self.source = source
        self.is_camera = source.isdigit()
        self.cap = cv2.VideoCapture(int(source) if self.is_camera else source)
        if not self.cap.isOpened():
            raise IOError(f"Could not open video source: {source}")
        self.is_live = self.is_camera or "://" in source
        fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.fps = fps if fps and fps > 0 and fps < 1000 else 25.0
        n = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        self.total_frames = n if n > 0 and not self.is_live else None
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.step = max(1, int(every_n_frames) if every_n_frames else int(round(self.fps * sample_every_seconds)))
        self.sample_every_seconds = sample_every_seconds
        self.max_seconds = max_seconds

    @property
    def expected_samples(self):
        if self.total_frames is None:
            return None
        n = self.total_frames
        if self.max_seconds:
            n = min(n, int(self.max_seconds * self.fps))
        return (n + self.step - 1) // self.step

    def frames(self):
        """Yields sampled frames. Files: every `step`-th frame. Live streams: one frame per interval of wall time."""
        idx = -1
        start = time.monotonic()
        next_live = 0.0
        try:
            while True:
                if not self.cap.grab():
                    break
                idx += 1
                if self.is_live:
                    t = time.monotonic() - start
                    if self.max_seconds and t > self.max_seconds:
                        break
                    if t < next_live:
                        continue
                    next_live = t + self.sample_every_seconds
                else:
                    t = idx / self.fps
                    if self.max_seconds and t > self.max_seconds:
                        break
                    if idx % self.step:
                        continue
                ok, img = self.cap.retrieve()
                if ok and img is not None:
                    yield Frame(idx, round(t, 3), img)
        finally:
            self.cap.release()
